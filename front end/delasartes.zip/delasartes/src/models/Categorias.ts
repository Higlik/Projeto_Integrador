
interface Categorias {
    id: number;
    genero: string;
    descricao: string;
}

export default Categorias;